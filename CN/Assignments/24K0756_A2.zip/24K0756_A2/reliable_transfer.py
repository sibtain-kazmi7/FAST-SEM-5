import argparse
import random
import heapq
import time

class Simulator:
    def __init__(self, protocol, packets, window, bits, loss, corruption, delay, timeout, seed, verbose=True):
        self.protocol = protocol.lower()
        self.total = packets
        self.N = window
        self.mod = 1 << bits
        if self.protocol == 'sr' and window > self.mod // 2:
            raise ValueError('SR requires window size <= 2^(k-1).')
        if self.protocol == 'gbn' and window > self.mod - 1:
            raise ValueError('GBN requires window size <= 2^k - 1.')
        self.loss, self.corruption, self.delay, self.timeout = loss, corruption, delay, timeout
        self.rng = random.Random(seed)
        self.verbose = verbose
        self.base = 0
        self.nextseqnum = 0
        self.rcv_base = 0
        self.expectedseqnum = 0
        self.acked = set()
        self.timers = {}
        self.buffer = {}
        self.delivered = set()
        self.events = []
        self.serial = 0
        self.tick = 0
        self.transmitted = 0
        self.retransmissions = 0
        self.successful_deliveries = 0

    def log(self, msg):
        if self.verbose:
            print(f'[t={self.tick:04d}] {msg}')

    def schedule(self, due, kind, seq, corrupt=False):
        self.serial += 1
        heapq.heappush(self.events, (due, self.serial, kind, seq, corrupt))

    def channel_send(self, kind, seq):
        self.transmitted += (kind == 'DATA')
        if self.rng.random() < self.loss:
            self.log(f'CHANNEL LOSS: {kind} seq={seq % self.mod}')
            return
        corrupt = self.rng.random() < self.corruption
        extra = self.rng.randint(1, 4) if self.rng.random() < self.delay else 0
        if corrupt:
            self.log(f'CHANNEL CORRUPTION: {kind} seq={seq % self.mod}; checksum will fail')
        if extra:
            self.log(f'CHANNEL DELAY: {kind} seq={seq % self.mod} by {extra} ticks')
        self.schedule(self.tick + 1 + extra, kind, seq, corrupt)

    def send_data(self, seq, retrans=False):
        self.log(f'{"RETRANSMIT" if retrans else "SEND"} packet abs={seq}, seq={seq % self.mod}; base={self.base}, nextseqnum={self.nextseqnum}')
        if retrans:
            self.retransmissions += 1
        self.timers[seq] = self.tick
        self.channel_send('DATA', seq)

    def process_data(self, seq, corrupt):
        if corrupt:
            self.log(f'RECEIVER checksum failure for packet seq={seq % self.mod}; discard')
            return
        if self.protocol == 'gbn':
            if seq == self.expectedseqnum:
                self.log(f'RECEIVER accepts packet {seq}; expectedseqnum={self.expectedseqnum}')
                self.delivered.add(seq)
                self.successful_deliveries = len(self.delivered)
                self.expectedseqnum += 1
                ack = self.expectedseqnum - 1
            else:
                self.log(f'RECEIVER discards out-of-order/duplicate packet {seq}; expectedseqnum={self.expectedseqnum}')
                ack = self.expectedseqnum - 1
            self.log(f'SEND cumulative ACK {ack % self.mod} (through absolute packet {ack})')
            self.channel_send('ACK', ack)
        else:
            if seq >= self.rcv_base and seq < self.rcv_base + self.N:
                if seq not in self.buffer and seq not in self.delivered:
                    self.buffer[seq] = True
                    self.log(f'SR receiver buffers packet {seq}; rcv_base={self.rcv_base}')
                else:
                    self.log(f'SR receiver got duplicate packet {seq}')
                self.log(f'SEND individual ACK {seq % self.mod} (absolute {seq})')
                self.channel_send('ACK', seq)
                while self.rcv_base in self.buffer:
                    self.buffer.pop(self.rcv_base)
                    self.delivered.add(self.rcv_base)
                    self.log(f'SR delivers buffered/in-order packet {self.rcv_base}')
                    self.rcv_base += 1
                    self.successful_deliveries = len(self.delivered)
            elif seq < self.rcv_base:
                self.log(f'SR duplicate old packet {seq}; ACK again')
                self.channel_send('ACK', seq)
            else:
                self.log(f'SR packet {seq} outside receiver window; discard')

    def process_ack(self, seq, corrupt):
        if corrupt:
            self.log(f'SENDER checksum failure for ACK seq={seq % self.mod}; ignore')
            return
        if self.protocol == 'gbn':
            self.log(f'RECEIVE cumulative ACK {seq % self.mod} (through absolute packet {seq})')
            if seq >= self.base:
                newbase = min(seq + 1, self.total)
                for s in list(self.timers):
                    if s < newbase:
                        self.timers.pop(s, None)
                self.base = newbase
        else:
            self.log(f'RECEIVE individual ACK {seq % self.mod} (absolute {seq})')
            if self.base <= seq < self.nextseqnum:
                self.acked.add(seq)
                self.timers.pop(seq, None)
                while self.base in self.acked:
                    self.acked.remove(self.base)
                    self.base += 1

    def run(self):
        start = time.perf_counter()
        idle_guard = 0
        while self.base < self.total and self.tick < 1000000:
            # Deliver events due now.
            while self.events and self.events[0][0] <= self.tick:
                _, _, kind, seq, corrupt = heapq.heappop(self.events)
                if kind == 'DATA':
                    self.log(f'RECEIVE DATA packet abs={seq}, wire_seq={seq % self.mod}')
                    self.process_data(seq, corrupt)
                else:
                    self.log(f'RECEIVE ACK abs={seq}, wire_seq={seq % self.mod}')
                    self.process_ack(seq, corrupt)
            # Timeout logic.
            if self.protocol == 'gbn':
                if self.base < self.nextseqnum and self.base in self.timers and self.tick - self.timers[self.base] >= self.timeout:
                    self.log(f'TIMEOUT oldest unACKed packet {self.base}; GBN resends all outstanding packets')
                    for s in range(self.base, self.nextseqnum):
                        self.send_data(s, retrans=True)
            else:
                for s in range(self.base, self.nextseqnum):
                    if s not in self.acked and s in self.timers and self.tick - self.timers[s] >= self.timeout:
                        self.log(f'TIMEOUT packet {s}; SR resends only this packet')
                        self.send_data(s, retrans=True)
            # Fill sender window.
            while self.nextseqnum < self.total and self.nextseqnum < self.base + self.N:
                s = self.nextseqnum
                self.nextseqnum += 1
                self.send_data(s)
            if not self.events and self.base < self.total and self.nextseqnum == self.total:
                idle_guard += 1
                if idle_guard > 2:
                    self.tick += 1
                    idle_guard = 0
            self.tick += 1
        elapsed = time.perf_counter() - start
        self.log(f'FINISHED: delivered={self.successful_deliveries}/{self.total}, transmissions={self.transmitted}, retransmissions={self.retransmissions}, ticks={self.tick}')
        return {
            'protocol': self.protocol.upper(), 'packets': self.total,
            'transmissions': int(self.transmitted), 'retransmissions': self.retransmissions,
            'delivered': self.successful_deliveries, 'ticks': self.tick,
            'execution_seconds': elapsed
        }

def main():
    p = argparse.ArgumentParser(description='GBN/SR reliable transfer simulator with an unreliable channel')
    p.add_argument('--protocol', choices=['gbn', 'sr'], required=True)
    p.add_argument('--packets', type=int, default=200)
    p.add_argument('--window', type=int, default=4)
    p.add_argument('--bits', type=int, default=3)
    p.add_argument('--loss', type=float, default=0.0)
    p.add_argument('--corruption', type=float, default=0.0)
    p.add_argument('--delay', type=float, default=0.0)
    p.add_argument('--timeout', type=int, default=12)
    p.add_argument('--seed', type=int, default=756)
    p.add_argument('--quiet', action='store_true')
    a = p.parse_args()
    if a.packets < 1 or a.window < 1 or a.bits < 1 or a.timeout < 1:
        p.error('packets, window, bits and timeout must be positive')
    for name, value in [('loss', a.loss), ('corruption', a.corruption), ('delay', a.delay)]:
        if not 0 <= value <= 1:
            p.error(f'{name} must be between 0 and 1')
    result = Simulator(a.protocol, a.packets, a.window, a.bits, a.loss, a.corruption, a.delay, a.timeout, a.seed, not a.quiet).run()
    print('\nRESULTS')
    for k, v in result.items():
        print(f'{k}: {v}')

if __name__ == '__main__':
    main()
