CN Assignment II — 24K-0756

Sample commands
1) GBN, 200 packets, reliable channel:
   python reliable_transfer.py --protocol gbn --packets 200 --window 4 --bits 3 --loss 0 --corruption 0 --delay 0 --timeout 12 --seed 756
2) SR, packet-loss experiment:
   python reliable_transfer.py --protocol sr --packets 200 --window 4 --bits 3 --loss 0.10 --corruption 0 --delay 0 --timeout 12 --seed 756
3) SR, mixed-error experiment:
   python reliable_transfer.py --protocol sr --packets 200 --window 4 --bits 3 --loss 0.05 --corruption 0.05 --delay 0.10 --timeout 12 --seed 756

Parameters
--protocol gbn|sr     protocol selection
--packets N            number of data packets
--window N             sender window size
--bits k               sequence number bits; wire sequence numbers wrap modulo 2^k
--loss p               loss probability for data packets and ACKs
--corruption p         corruption probability; detected by simulated checksum
--delay p              probability that a packet/ACK is delayed by 1–4 simulation ticks
--timeout N            timeout in simulation ticks
--seed N               deterministic random seed (use your roll number's last four digits)
--quiet                suppress detailed event log; only print summary

Assumptions / limitations
- The simulator uses integer simulation ticks rather than real network time. A probabilistically delayed packet arrives 1–4 ticks later.
- The internal simulator tracks absolute packet identities so that its event queue can model wraparound unambiguously; displayed sequence numbers are modulo 2^k.
- A corrupted packet or ACK fails checksum validation and is discarded.
- GBN uses cumulative ACKs and retransmits all outstanding packets after the oldest unacknowledged packet times out.
- SR uses individual ACKs, receiver buffering, and per-packet timers; only timed-out packets are retransmitted.
- The provided experiment table is generated with seed 756, N=4, k=3, timeout=12. Execution time depends on machine/load, so simulation ticks are used for reproducible comparisons.
